// This file is deprecated for database storage. 
// See data/exerciseDb.ts for the Exercise Database.
// Kept to avoid breaking implicit references if any, but logically empty.
export const TRAINING_TEMPLATES = [];
